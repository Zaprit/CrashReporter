function DismissReport(id, reason) {
    
}
    const form = document.getElementById("ReportForm");